"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import WelcomeCard from "./WelcomeCard";
import QuickStats from "./QuickStats";
import RecentConnections from "./RecentConnections";
import UpcomingEvents from "./UpcomingEvents";
import AppHeader from "../ui/AppHeader";

export default function Dashboard() {
  const router = useRouter();

  // Mock data for the components
  const stats = {
    connections: 42,
    messages: 24,
    events: 8,
    profileComplete: 89,
  };

  const connections = [
    {
      id: "1",
      name: "Sarah Chen",
      title: "AI Startup Founder",
      company: "TechFlow AI",
      connectedAt: new Date("2024-12-13T10:00:00Z"),
    },
    {
      id: "2",
      name: "Marcus Johnson",
      title: "Fintech Entrepreneur",
      company: "PayStream",
      connectedAt: new Date("2024-12-12T15:30:00Z"),
    },
    {
      id: "3",
      name: "Lisa Rodriguez",
      title: "E-commerce Founder",
      company: "ShopSmart",
      connectedAt: new Date("2024-12-10T09:15:00Z"),
    },
  ];

  const events = [
    {
      id: "1",
      title: "Tech Founders Meetup",
      date: new Date("2024-12-15T18:00:00Z"),
      location: "San Francisco",
      attendees: 42,
    },
    {
      id: "2",
      title: "Startup Pitch Night",
      date: new Date("2024-12-18T19:00:00Z"),
      location: "Virtual",
      attendees: 156,
    },
    {
      id: "3",
      title: "AI Innovation Summit",
      date: new Date("2024-12-22T09:00:00Z"),
      location: "New York",
      attendees: 298,
    },
  ];

  const founder = {
    id: "1",
    name: "Current User",
    title: "Founder",
    company: "Your Company",
  };

  const handleGetStarted = () => {
    router.push("/profile");
  };

  return (
    <div className="fixed inset-0 w-screen h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 overflow-auto">
      {/* Header Menu with Logo */}
      <AppHeader currentPage="Dashboard" />

      {/* Welcome Section */}
      <div className="w-full py-8">
        <WelcomeCard onGetStarted={handleGetStarted} />
      </div>

      {/* Quick Stats */}
      <div className="w-full pb-8">
        <QuickStats stats={stats} />
      </div>

      {/* Main Content Grid - BEAUTIFUL DESIGN */}
      <div className="w-full pb-12">
        <div className="w-full grid grid-cols-1 xl:grid-cols-2 gap-8 px-4">
          {/* Left Column - Recent Connections */}
          <div className="w-full">
            <div className="bg-white/95 backdrop-blur-md rounded-3xl shadow-xl border border-white/30 p-8 w-full min-h-[700px] hover:shadow-2xl transition-all duration-500 hover:scale-[1.02]">
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl shadow-lg">
                    <svg
                      className="w-8 h-8 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      />
                    </svg>
                  </div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Recent Connections
                  </h3>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                  <span>3 online</span>
                </div>
              </div>
              <div className="space-y-6">
                {connections.map((connection, index) => (
                  <div
                    key={index}
                    className="group relative overflow-hidden p-6 bg-gradient-to-r from-blue-50/80 to-purple-50/80 rounded-2xl hover:from-blue-100 hover:to-purple-100 transition-all duration-300 border border-blue-100/60 hover:border-blue-300 hover:shadow-xl cursor-pointer transform hover:-translate-y-1"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative flex items-center space-x-6">
                      <div className="relative">
                        <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl group-hover:shadow-2xl transition-all duration-300 group-hover:scale-110">
                          <span className="text-white font-bold text-2xl">
                            {connection.name.charAt(0)}
                          </span>
                        </div>
                        <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-400 rounded-full border-3 border-white shadow-lg">
                          <div className="w-full h-full bg-green-400 rounded-full animate-ping"></div>
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xl font-bold text-gray-900 group-hover:text-blue-700 transition-colors truncate">
                          {connection.name}
                        </p>
                        <p className="text-base text-gray-600 mt-1 font-medium">
                          {connection.title}
                        </p>
                        <p className="text-sm text-blue-600 font-semibold mt-1">
                          {connection.company}
                        </p>
                        <div className="flex items-center mt-2 space-x-2">
                          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                          <span className="text-xs text-gray-500">
                            Active now
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end space-y-3">
                        <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl text-sm font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
                          Message
                        </button>
                        <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">
                          2h ago
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-10">
                <button className="w-full py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl font-bold text-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:-translate-y-1 hover:scale-[1.02]">
                  View All Connections
                </button>
              </div>
            </div>
          </div>

          {/* Right Column - Upcoming Events */}
          <div className="w-full">
            <div className="bg-white/95 backdrop-blur-md rounded-3xl shadow-xl border border-white/30 p-8 w-full min-h-[700px] hover:shadow-2xl transition-all duration-500 hover:scale-[1.02]">
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-gradient-to-r from-green-500 to-blue-600 rounded-2xl shadow-lg">
                    <svg
                      className="w-8 h-8 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                  </div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                    Upcoming Events
                  </h3>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></span>
                  <span>3 this week</span>
                </div>
              </div>
              <div className="space-y-6">
                {events.map((event, index) => (
                  <div
                    key={index}
                    className="group relative overflow-hidden p-6 bg-gradient-to-r from-green-50/80 to-blue-50/80 rounded-2xl hover:from-green-100 hover:to-blue-100 transition-all duration-300 border border-green-100/60 hover:border-green-300 hover:shadow-xl cursor-pointer transform hover:-translate-y-1"
                  >
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-green-500 to-blue-500 group-hover:w-2 transition-all duration-300"></div>
                    <div className="absolute inset-0 bg-gradient-to-r from-green-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative flex items-start justify-between">
                      <div className="flex-1 min-w-0 pr-4">
                        <h4 className="text-xl font-bold text-gray-900 group-hover:text-green-700 transition-colors mb-4">
                          {event.title}
                        </h4>
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-green-100 rounded-lg">
                              <svg
                                className="w-4 h-4 text-green-600"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                />
                              </svg>
                            </div>
                            <p className="text-base text-gray-700 font-medium">
                              {event.date.toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              <svg
                                className="w-4 h-4 text-blue-600"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                                />
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                                />
                              </svg>
                            </div>
                            <p className="text-base text-gray-700 font-medium">
                              {event.location}
                            </p>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-purple-100 rounded-lg">
                              <svg
                                className="w-4 h-4 text-purple-600"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                                />
                              </svg>
                            </div>
                            <p className="text-sm text-green-600 font-semibold bg-green-100 px-3 py-1 rounded-full">
                              {event.attendees} attending
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end space-y-3">
                        <button className="px-6 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl text-sm font-semibold hover:from-green-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105">
                          Join Event
                        </button>
                        <div className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                          {index === 0
                            ? "Tomorrow"
                            : index === 1
                            ? "In 3 days"
                            : "Next week"}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-10">
                <button className="w-full py-4 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-2xl font-bold text-lg hover:from-green-600 hover:to-blue-700 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:-translate-y-1 hover:scale-[1.02]">
                  Browse All Events
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
